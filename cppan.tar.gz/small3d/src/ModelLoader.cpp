/*
 *  ModelLoader.cpp
 *
 *  Created on: 2014/11/12
 *      Author: Dimitri Kourkoulis
 *     License: BSD 3-Clause License (see LICENSE file)
 */

#include "ModelLoader.hpp"

namespace small3d {

  void ModelLoader::load(std::string filename, Model &model )
  {

  }

}
